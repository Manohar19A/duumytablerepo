const Course = [
  {
    courseName: "Java",
    key: "1",
    label: "Java",
  },

  {
    courseName: "Python",
    key: "2",
    label: "Python",
  },

  {
    courseName: "React",
    key: "3",
    label: "React",
  },

  {
    courseName: "Boostarp",
    key: "4",
    label: "Boostarp",
  },
];

export default Course;
