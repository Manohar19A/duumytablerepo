import React from 'react'
import { Button}  from 'react-bootstrap'
const Modal1 = () => {
  return (
    <div>
        <Button>Edit</Button>
        <Button>Delete</Button>
    </div>
  )
}
export default Modal1
